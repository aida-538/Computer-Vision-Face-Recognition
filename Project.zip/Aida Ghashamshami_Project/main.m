function main()
    clc;
    

    % 1) Run classifier
    dl_classify_face();

    % 2) Run segmentation+PSNR grid 
    segmentation_psnr_grid();

    % 3) Run Aida similarity 
    Aida_similarity();

    
    figNums = [10 100 200 400];  
    for f = figNums
        if isgraphics(f)
            figure(f);
            drawnow;
        end
    end
end
