function hFig = Aida_similarity()

  
    thisFile = mfilename('fullpath');
    [projectRoot, ~, ~] = fileparts(thisFile);

    % Settings
    targetSize = [256 256];
    nbins = 40;

    % Paths
    me1Path  = fullfile(projectRoot, 'img-data', 'me',     'me_3.jpg');
    me2Path  = fullfile(projectRoot, 'img-data', 'me',     'me_9.jpg');
    refPath  = fullfile(projectRoot, 'uploads',  'test_image.jpg');
    oth1Path = fullfile(projectRoot, 'img-data', 'not me', 'Other_6.jpg');
    oth2Path = fullfile(projectRoot, 'img-data', 'not me', 'Other_9.jpg');

    % Read/resize
    Me1 = iReadAndResize(me1Path, targetSize);
    Me2 = iReadAndResize(me2Path, targetSize);
    Ref = iReadAndResize(refPath, targetSize);
    O1  = iReadAndResize(oth1Path, targetSize);
    O2  = iReadAndResize(oth2Path, targetSize);

    % Compute metrics
    mMe1 = computeMetrics(Me1, Ref, nbins);
    mMe2 = computeMetrics(Me2, Ref, nbins);
    mO1  = computeMetrics(O1,  Ref, nbins);
    mO2  = computeMetrics(O2,  Ref, nbins);

    
    hFig = figure(100);
    clf(hFig);
    set(hFig, 'Name', 'Similarity vs Reference (test_image)', 'Color', 'w');


    set(hFig, 'CloseRequestFcn', @(src,evt) delete(src)); 

    t = tiledlayout(hFig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');

    % Left column my photos
    nexttile(t, 1);
    imshow(Me1);
    title(metricsTitle('me_3', mMe1), 'Interpreter','none');

    nexttile(t, 4);
    imshow(Me2);
    title(metricsTitle('me_9', mMe2), 'Interpreter','none');

    % Middle column reference
    nexttile(t, 2, [2 1]);
    imshow(Ref);
    title('Reference: test_image', 'Interpreter','none', 'FontWeight','bold');

    % Right column other photos
    nexttile(t, 3);
    imshow(O1);
    title(metricsTitle('Other_6', mO1), 'Interpreter','none');

    nexttile(t, 6);
    imshow(O2);
    title(metricsTitle('Other_9', mO2), 'Interpreter','none');

    title(t, 'Similarity Metrics (each image compared to reference)', 'FontWeight','bold');
    % Signature
subtitle(t, 'Signature: Aida Ghashamshami', ...
    'FontWeight','bold', ...
    'FontSize', 11);


    drawnow;  
end

%helpers

function I = iReadAndResize(filename, targetSize)
    if ~isfile(filename)
        error('File not found:\n%s', filename);
    end
    I = imread(filename);
    I = imresize(I, targetSize);
end

function M = computeMetrics(img, ref, nbins)
    gImg = toGray(img);
    gRef = toGray(ref);

    M.ssim = ssim(gImg, gRef);
    M.mse  = immse(gImg, gRef);
    M.psnr = psnr(gImg, gRef);

    hImg = imhist(gImg, nbins);
    hRef = imhist(gRef, nbins);

    M.chi  = chi_square_statistics(hImg', hRef');
    M.hint = histogram_intersection(hImg', hRef');
end

function g = toGray(I)
    if size(I,3) == 3
        g = rgb2gray(I);
    else
        g = I;
    end
end

function s = metricsTitle(name, M)
    s = sprintf([ ...
        '%s\n' ...
        'SSIM: %0.4f | MSE: %0.1f\n' ...
        'Chi:  %0.2f  | H-I: %0.4f | PSNR: %0.2f dB'], ...
        name, M.ssim, M.mse, M.chi, M.hint, M.psnr);
end

