function segmentation_psnr_grid()


    rng(0,'twister');  

    
    thisFile = mfilename('fullpath');
    [projectRoot,~,~] = fileparts(thisFile);

    
    refPath  = fullfile(projectRoot,'img-data','me','me_3.jpg');     
    me1Path  = fullfile(projectRoot,'img-data','me','me_9.jpg');
    me2Path  = fullfile(projectRoot,'img-data','me','me_11.jpg');

    oth1Path = iFindExisting({ ...
        fullfile(projectRoot,'img-data','not me','other_14.jpg'), ...
        fullfile(projectRoot,'img-data','not me','Other_14.jpg') ...
    });

    oth2Path = iFindExisting({ ...
        fullfile(projectRoot,'img-data','not me','other_16.jpg'), ...
        fullfile(projectRoot,'img-data','not me','Other_16.jpg') ...
    });

    % load + resize 
    targetSize = [256 256];
    Ref  = iReadRGB(refPath,  targetSize);
    Me1  = iReadRGB(me1Path,  targetSize);
    Me2  = iReadRGB(me2Path,  targetSize);
    Oth1 = iReadRGB(oth1Path, targetSize);
    Oth2 = iReadRGB(oth2Path, targetSize);

    % segmentation methods
    methods = { ...
        struct('name','HSV',          'fn',@segHSV), ...
        struct('name','Otsu',         'fn',@segOtsu), ...
        struct('name','KMeans',       'fn',@segKMeans), ...
        struct('name','SVM',          'fn',@segSVMpseudo) ...
    };

    % figure layout
    figure(400); clf;
    set(gcf,'Color','w','Name','Segmentations — Me (2) | Reference | Other (2) — Metric: PSNR');

    t = tiledlayout(4,5,'TileSpacing','compact','Padding','compact');
    title(t, 'Segmentations - Metric: PSNR (on grayscale segmented outputs)', ...
        'FontWeight','bold');

    colTitles = {'Me #1 (me_9)','Me #2 (me_11)','Reference (me_3)','Other #1 (other_14)','Other #2 (other_16)'};

    for r = 1:numel(methods)
        methodName = methods{r}.name;
        segFn      = methods{r}.fn;

        
        Sme1 = segFn(Me1);
        Sme2 = segFn(Me2);
        Sref = segFn(Ref);
        Soth1= segFn(Oth1);
        Soth2= segFn(Oth2);

        % Compute PSNR on grayscale segmented outputs, using double in [0,1]
        pMe1  = psnr(im2double(rgb2graySafe(Sme1)),  im2double(rgb2graySafe(Sref)));
        pMe2  = psnr(im2double(rgb2graySafe(Sme2)),  im2double(rgb2graySafe(Sref)));
        pOth1 = psnr(im2double(rgb2graySafe(Soth1)), im2double(rgb2graySafe(Sref)));
        pOth2 = psnr(im2double(rgb2graySafe(Soth2)), im2double(rgb2graySafe(Sref)));


        ax = nexttile((r-1)*5 + 1);
        imshow(Sme1,'Parent',ax);
        if r==1, title(colTitles{1},'Interpreter','none'); end
        xlabel(sprintf('%s\nPSNR(Me1,Ref): %.2f dB', methodName, pMe1), 'FontWeight','bold');

        % Col 2
        ax = nexttile((r-1)*5 + 2);
        imshow(Sme2,'Parent',ax);
        if r==1, title(colTitles{2},'Interpreter','none'); end
        xlabel(sprintf('PSNR(Me2,Ref): %.2f dB', pMe2), 'FontWeight','bold');

        % Col 3 (reference)
        ax = nexttile((r-1)*5 + 3);
        imshow(Sref,'Parent',ax);
        if r==1, title(colTitles{3},'Interpreter','none'); end
        xlabel('Reference', 'FontWeight','bold');

        % Col 4
        ax = nexttile((r-1)*5 + 4);
        imshow(Soth1,'Parent',ax);
        if r==1, title(colTitles{4},'Interpreter','none'); end
        xlabel(sprintf('PSNR(Other1,Ref): %.2f dB', pOth1), 'FontWeight','bold');

        % Col 5
        ax = nexttile((r-1)*5 + 5);
        imshow(Soth2,'Parent',ax);
        if r==1, title(colTitles{5},'Interpreter','none'); end
        xlabel(sprintf('PSNR(Other2,Ref): %.2f dB', pOth2), 'FontWeight','bold');
    end

    
    fprintf('\n=== PSNR on grayscale segmented outputs (vs Reference me_3) ===\n');
    for r = 1:numel(methods)
        methodName = methods{r}.name;
        segFn      = methods{r}.fn;
        Sref = segFn(Ref);

        pMe1  = psnr(im2double(rgb2graySafe(segFn(Me1))),  im2double(rgb2graySafe(Sref)));
        pMe2  = psnr(im2double(rgb2graySafe(segFn(Me2))),  im2double(rgb2graySafe(Sref)));
        pOth1 = psnr(im2double(rgb2graySafe(segFn(Oth1))), im2double(rgb2graySafe(Sref)));
        pOth2 = psnr(im2double(rgb2graySafe(segFn(Oth2))), im2double(rgb2graySafe(Sref)));

        fprintf('%-6s | Me1: %6.2f  Me2: %6.2f  Other1: %6.2f  Other2: %6.2f (dB)\n', ...
            methodName, pMe1, pMe2, pOth1, pOth2);
    end
    fprintf('\n');
        % Signature superimposed
    sig = 'Signature: Aida Ghashamshami';

annotation('textbox', [0.78 0.962 0.20 0.03], ...
    'String', 'Signature: Aida Ghashamshami', ...
    'EdgeColor', 'k', 'BackgroundColor', 'w', ...
    'HorizontalAlignment', 'right', ...
    'FontWeight', 'bold', 'FontSize', 10);



end


% Helpers


function p = iFindExisting(candidates)
    for i = 1:numel(candidates)
        if isfile(candidates{i})
            p = candidates{i};
            return;
        end
    end
    error("Could not find file. Tried:\n%s", strjoin(candidates, newline));
end

function I = iReadRGB(path, targetSize)
    if ~isfile(path)
        error('File not found:\n%s', path);
    end
    I = imread(path);
    if size(I,3)==1
        I = repmat(I,1,1,3);
    end
    I = imresize(I, targetSize);
    I = im2uint8(I);
end

function g = rgb2graySafe(I)
    if size(I,3)==3
        g = rgb2gray(I);
    else
        g = I;
    end
end





% 1) HSV segmentation
function S = segHSV(I)
    Ihsv = rgb2hsv(I);
    Xhsv = reshape(Ihsv, [], 3);

    k = 4;
    idx = kmeans(Xhsv, k, ...
        'MaxIter', 200, ...
        'Replicates', 3, ...
        'Start','plus', ...
        'EmptyAction','singleton');

    Xrgb = reshape(im2double(I), [], 3);
    Sflat = zeros(size(Xrgb));

    for c = 1:k
        sel = (idx == c);
        if any(sel)
            mu = mean(Xrgb(sel,:), 1);
            Sflat(sel,:) = repmat(mu, sum(sel), 1);
        end
    end
    S = im2uint8(reshape(Sflat, size(im2double(I))));
end

% 2) Otsu thresholding
function S = segOtsu(I)
    G = rgb2gray(I);
    level = graythresh(G);
    BW = imbinarize(G, level);

    BW = bwareafilt(BW, 1);
    BW = imfill(BW, 'holes');

    S = I;
    mask = repmat(BW,1,1,3);
    S(~mask) = 0;
end

% 3) KMeans segmentation in RGB
function S = segKMeans(I)
    X = reshape(im2double(I), [], 3);
    k = 3;

    idx = kmeans(X, k, ...
        'MaxIter', 200, ...
        'Replicates', 3, ...
        'Start','plus', ...
        'EmptyAction','singleton');

    Sflat = zeros(size(X));
    for c = 1:k
        sel = (idx == c);
        if any(sel)
            mu = mean(X(sel,:), 1);
            Sflat(sel,:) = repmat(mu, sum(sel), 1);
        end
    end
    S = im2uint8(reshape(Sflat, size(im2double(I))));
end

% 4) SVM segmentation
function S = segSVMpseudo(I)
    G = rgb2gray(I);
    level = graythresh(G);
    BW = imbinarize(G, level);
    BW = bwareafilt(BW, 1);
    BW = imfill(BW,'holes');

    [h,w,~] = size(I);
    [xx,yy] = meshgrid(1:w, 1:h);

    R = double(I(:,:,1)); Gc = double(I(:,:,2)); B = double(I(:,:,3));
    X = [R(:), Gc(:), B(:), xx(:)/w, yy(:)/h];
    y = BW(:);

    
    rng(0);
    pos = find(y==1); neg = find(y==0);
    nPos = min(3000, numel(pos));
    nNeg = min(3000, numel(neg));
    sel = [pos(randperm(numel(pos), nPos)); neg(randperm(numel(neg), nNeg))];

    mdl = fitcsvm(X(sel,:), y(sel), ...
        'KernelFunction','rbf', ...
        'Standardize',true, ...
        'ClassNames',[0 1]);

    yhat = predict(mdl, X);
    BW2 = reshape(yhat, h, w);

    BW2 = bwareafilt(BW2, 1);
    BW2 = imfill(BW2,'holes');

    S = I;
    mask = repmat(BW2,1,1,3);
    S(~mask) = 0;
end
