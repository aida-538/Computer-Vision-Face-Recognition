function dl_classify_face()
    % Reproducible 
    close all; clc;
    rng(0,'twister');   % makes all random selections repeatable

    cRootPath = pwd;

    
    % 1) Load train/val dataset
   
    trainPath = fullfile(cRootPath,'img-data');
    imdsAll = imageDatastore(trainPath, ...
        'IncludeSubfolders', true, ...
        'LabelSource', 'foldernames');

    % Resize + force RGB
    targetSize = [224 224];
    imdsAll.ReadFcn = @(fn) iReadAndResize(fn, targetSize);

    disp("=== img-data label counts ===")
    disp(countEachLabel(imdsAll))

    
    % Fixed split: 10 train / class, 5 val / class

    classes = categories(imdsAll.Labels);
    nTrainPerClass = 10;
    nValPerClass   = 5;

    idxTrain = [];
    idxVal   = [];

    for k = 1:numel(classes)
        cls = classes{k};
        idx = find(imdsAll.Labels == cls);

        % deterministic shuffle per class
        idx = idx(randperm(numel(idx)));

        if numel(idx) < (nTrainPerClass + nValPerClass)
            error("Not enough images in class '%s'. Need at least %d, found %d.", ...
                cls, (nTrainPerClass + nValPerClass), numel(idx));
        end

        idxTrain = [idxTrain; idx(1:nTrainPerClass)];
        idxVal   = [idxVal;   idx(nTrainPerClass+1 : nTrainPerClass+nValPerClass)];
    end

    imdsTrain = subset(imdsAll, idxTrain);
    imdsVal   = subset(imdsAll, idxVal);

    fprintf("Train size = %d (=%d per class)\n", numel(imdsTrain.Files), nTrainPerClass);
    fprintf("Val   size = %d (=%d per class)\n", numel(imdsVal.Files),   nValPerClass);

    
    % 2) Load trained model
    
    S = load('face_model.mat','net');
    net = S.net;

    
    % 3) Validation evaluation
    
    YPredVal = classify(net, imdsVal);
    YTrueVal = imdsVal.Labels;
    accVal = mean(YPredVal == YTrueVal);

    fprintf("\nValidation accuracy = %.2f%% (%d images)\n", accVal*100, numel(YTrueVal));

    % Confusion matrix 
    Cval = confusionmat(YTrueVal, YPredVal, 'Order', categorical(classes));
    figure; iPlotConfMat(Cval, classes, sprintf("VALIDATION Confusion Matrix (Acc = %.2f%%)", accVal*100));

annotation('textbox', [0.35 0.955 0.30 0.04], ...
    'String', 'Signature: Aida Ghashamshami', ...
    'EdgeColor', 'k', ...
    'BackgroundColor', 'w', ...
    'HorizontalAlignment', 'center', ...
    'FontWeight', 'bold', ...
    'FontSize', 11);

    
    % 4) Fixed test set (test0)
    % exactly 10 images: 5 me + 5 not me
    
    testPath = fullfile(cRootPath,'test0');
    imdsTestAll = imageDatastore(testPath, ...
        'IncludeSubfolders', true, ...
        'LabelSource', 'foldernames');
    imdsTestAll.ReadFcn = @(fn) iReadAndResize(fn, targetSize);

    disp("=== test0 label counts ===")
    disp(countEachLabel(imdsTestAll))

    
 
    testClasses = categories(imdsTestAll.Labels);

  
    nTestPerClass = 5;
    idxTest = [];

    for k = 1:numel(testClasses)
        cls = testClasses{k};
        idx = find(imdsTestAll.Labels == cls);
        idx = idx(randperm(numel(idx))); 

        if numel(idx) < nTestPerClass
            error("Not enough TEST images in class '%s'. Need %d, found %d.", ...
                cls, nTestPerClass, numel(idx));
        end

        idxTest = [idxTest; idx(1:nTestPerClass)];
    end

    imdsTest = subset(imdsTestAll, idxTest);

    YPredTest = classify(net, imdsTest);
    YTrueTest = imdsTest.Labels;
    accTest = mean(YPredTest == YTrueTest);

    fprintf("\nTest accuracy = %.2f%% (%d images; %d per class)\n", ...
        accTest*100, numel(YTrueTest), nTestPerClass);

    % Test confusion matrix 
    
    commonOrder = categories(categorical(union(categories(YTrueTest), categories(YPredTest))));
    Ctest = confusionmat(YTrueTest, YPredTest, 'Order', categorical(commonOrder));
    figure; iPlotConfMat(Ctest, commonOrder, sprintf("TEST Confusion Matrix (Acc = %.2f%%)", accTest*100));

    
    % 5) Show test images + T/P
    
    figure(10); clf;
    nTest = numel(imdsTest.Files);
    nCols = 3;
    nRows = ceil(nTest/nCols);

    for i = 1:nTest
        subplot(nRows, nCols, i);
        img = imdsTest.readimage(i);
        imshow(img);
        title(sprintf("T=%s | P=%s", string(YTrueTest(i)), string(YPredTest(i))));
    end
    %Signature
annotation('textbox', [0.35 0.955 0.30 0.04], ...
    'String', 'Signature: Aida Ghashamshami', ...
    'EdgeColor', 'k', ...
    'BackgroundColor', 'w', ...
    'HorizontalAlignment', 'center', ...
    'FontWeight', 'bold', ...
    'FontSize', 11);

end

% read, resize, force RGB
function I = iReadAndResize(filename, targetSize)
    I = imread(filename);
    if size(I,3) == 1
        I = repmat(I,1,1,3); % grayscale - RGB
    end
    I = imresize(I, targetSize);
end

% confusion matrix plot 
function iPlotConfMat(C, classNames, ttl)
    imagesc(C);
    annotation('textbox', [0.35 0.955 0.30 0.04], ...
    'String', 'Signature: Aida Ghashamshami', ...
    'EdgeColor', 'k', ...
    'BackgroundColor', 'w', ...
    'HorizontalAlignment', 'center', ...
    'FontWeight', 'bold', ...
    'FontSize', 11);

    axis image;
    colormap(parula);
    colorbar;

    n = size(C,1);
    xticks(1:n); yticks(1:n);
    xticklabels(classNames);
    yticklabels(classNames);

    xlabel('Predicted Class');
    ylabel('True Class');
    title(ttl);

    % Write all values including zeros in each cell
    for r = 1:n
        for c = 1:n
            text(c, r, num2str(C(r,c)), ...
                'HorizontalAlignment','center', ...
                'FontSize', 12, ...
                'FontWeight','bold', ...
                'Color','w');
        end
    end
end
